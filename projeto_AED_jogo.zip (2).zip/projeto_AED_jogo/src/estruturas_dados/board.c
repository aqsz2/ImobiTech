#include <string.h>
#include "board.h"

static void setProperty(Tile* tile, const char* name, int price, int rent) {
    tile->type = TILE_PROPERTY;
    strncpy(tile->property.name, name, sizeof(tile->property.name) - 1);
    tile->property.price = price;
    tile->property.rent = rent;
    tile->property.ownerIndex = -1;
    strncpy(tile->label, name, sizeof(tile->label) - 1);
}

void initBoard(Board* board) {
    // 24 casas: START, propriedades (bairros do Recife), eventos e MISTÉRIO
    memset(board, 0, sizeof(*board));

    board->tiles[0].type = TILE_START;
    strncpy(board->tiles[0].label, "START", sizeof(board->tiles[0].label) - 1);

    // Classe alta
    setProperty(&board->tiles[1],  "Boa Viagem", 380, 70);
    board->tiles[2].type = TILE_HACKATHON; strncpy(board->tiles[2].label, "Hackathon", 31);
    setProperty(&board->tiles[3],  "Graças", 360, 68);
    board->tiles[4].type = TILE_TAX; strncpy(board->tiles[4].label, "Imposto Dados", 31);
    setProperty(&board->tiles[5],  "Casa Forte", 340, 65);

    // Mistério
    board->tiles[6].type = TILE_MISTERIO; strncpy(board->tiles[6].label, "Mistério", 31);

    // Classe média alta
    setProperty(&board->tiles[7],  "Espinheiro", 300, 55);
    setProperty(&board->tiles[8],  "Parnamirim", 290, 52);
    board->tiles[9].type = TILE_BUG; strncpy(board->tiles[9].label, "Bug Sistema", 31);

    // Classe média
    setProperty(&board->tiles[10], "Madalena", 260, 46);
    setProperty(&board->tiles[11], "Torre", 250, 44);
    board->tiles[12].type = TILE_MISTERIO; strncpy(board->tiles[12].label, "Mistério", 31);
    setProperty(&board->tiles[13], "Boa Vista", 240, 42);

    // Taxa
    board->tiles[14].type = TILE_TAX; strncpy(board->tiles[14].label, "Imposto Dados", 31);

    // Classe média baixa
    setProperty(&board->tiles[15], "Iputinga", 200, 36);
    setProperty(&board->tiles[16], "Afogados", 180, 32);
    board->tiles[17].type = TILE_HACKATHON; strncpy(board->tiles[17].label, "Hackathon", 31);

    // Classe baixa
    setProperty(&board->tiles[18], "Ibura", 140, 26);
    setProperty(&board->tiles[19], "Cohab", 120, 22);

    // Mistério
    board->tiles[20].type = TILE_MISTERIO; strncpy(board->tiles[20].label, "Mistério", 31);

    // Pontos variados / turísticos
    setProperty(&board->tiles[21], "Bairro do Recife", 320, 60);
    board->tiles[22].type = TILE_BUG; strncpy(board->tiles[22].label, "Bug Sistema", 31);
    setProperty(&board->tiles[23], "Pina", 300, 55);
}
