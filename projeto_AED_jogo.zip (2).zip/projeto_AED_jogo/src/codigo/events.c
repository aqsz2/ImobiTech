#include <stdio.h>
#include <stdlib.h>
#include "events.h"
#include "ai.h"

void applyHackathon(GameState* state, int playerIndex) {
    int bonus = 150 + (rand() % 251); // 150..400
    state->players[playerIndex].balance += bonus;
    char aiText[256];
    aiGenerateText("Você brilhou no hackathon! Descreva o momento:", aiText, sizeof(aiText));
    snprintf(state->lastEventText, sizeof(state->lastEventText),
             "Hackathon! %s ganhou R$%d. %s", state->players[playerIndex].name, bonus, aiText);
}

void applyBug(GameState* state, int playerIndex) {
    int loss = 100 + (rand() % 201); // 100..300
    state->players[playerIndex].balance -= loss;
    char aiText[256];
    aiGenerateText("Um bug crítico ocorreu! Descreva o impacto:", aiText, sizeof(aiText));
    snprintf(state->lastEventText, sizeof(state->lastEventText),
             "Bug no sistema! %s perdeu R$%d. %s", state->players[playerIndex].name, loss, aiText);
}

void applyTax(GameState* state, int playerIndex) {
    int tax = state->players[playerIndex].balance / 10; // 10%
    if (tax < 100) tax = 100;
    state->players[playerIndex].balance -= tax;
    snprintf(state->lastEventText, sizeof(state->lastEventText),
             "Imposto de Dados! %s pagou R$%d em taxas.", state->players[playerIndex].name, tax);
}

void applyMisterio(GameState* state, int playerIndex) {
    // Decide um evento aleatório e direção de ajuste
    int good = rand() % 2; // 0 ruim, 1 bom
    int percent = 10 + (rand() % 21); // 10..30%
    int sign = good ? 1 : -1;

    // Ajusta preço e aluguel de TODAS as propriedades
    for (int i = 0; i < BOARD_SIZE; i++) {
        if (state->board.tiles[i].type == TILE_PROPERTY) {
            Property* pr = &state->board.tiles[i].property;
            pr->price = pr->price + (pr->price * percent * sign) / 100;
            if (pr->price < 10) pr->price = 10;
            pr->rent = pr->rent + (pr->rent * percent * sign) / 100;
            if (pr->rent < 1) pr->rent = 1;
        }
    }

    // Texto via IA descrevendo o acontecimento
    char aiText[256];
    if (good) {
        aiGenerateText("Um evento positivo afetou a economia (ex.: época de verão). Descreva o efeito:", aiText, sizeof(aiText));
    } else {
        aiGenerateText("Um evento negativo afetou a economia (ex.: pandemia, enchente no Recife). Descreva o efeito:", aiText, sizeof(aiText));
    }
    snprintf(state->lastEventText, sizeof(state->lastEventText),
             "Mistério! %s acionou um evento %s: %s\nTodos os preços e aluguéis mudaram em %d%%.",
             state->players[playerIndex].name, good ? "positivo" : "negativo", aiText, percent * sign);
}
