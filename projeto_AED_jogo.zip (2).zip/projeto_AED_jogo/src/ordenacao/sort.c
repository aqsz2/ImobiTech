#include "sort.h"

void sortPlayersByBalanceDesc(const GameState* state, int* outIndices) {
    int n = state->numPlayers;
    for (int i = 0; i < n; i++) outIndices[i] = i;
    // Bubble sort simples, n pequeno (<=4)
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            int a = outIndices[j];
            int b = outIndices[j + 1];
            if (state->players[a].balance < state->players[b].balance) {
                int tmp = outIndices[j];
                outIndices[j] = outIndices[j + 1];
                outIndices[j + 1] = tmp;
            }
        }
    }
}
