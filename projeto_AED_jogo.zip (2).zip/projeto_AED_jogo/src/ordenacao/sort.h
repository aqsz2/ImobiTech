#ifndef IMOBITECH_SORT_H
#define IMOBITECH_SORT_H

#include "game.h"

// Gera um array de índices [0..numPlayers-1] ordenado por saldo desc.
// outIndices deve ter tamanho >= state->numPlayers.
void sortPlayersByBalanceDesc(const GameState* state, int* outIndices);

#endif // IMOBITECH_SORT_H
