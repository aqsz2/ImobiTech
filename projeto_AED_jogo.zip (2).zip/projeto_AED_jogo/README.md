ImobiTech é uma releitura tecnológica do Banco Imobiliário, desenvolvida em C com Raylib. O jogo traz propriedades do mundo tech (startups, data centers, empresas de software), eventos especiais (Hackathon, Bug no Sistema, Imposto de Dados) e integração opcional com a API Gemini para gerar descrições dinâmicas.

## Recursos
- Tabuleiro com propriedades tecnológicas e casas de eventos
- Sistema de compra, aluguel e eliminação de jogadores
- Fim de jogo quando resta apenas 1 jogador com saldo positivo
- Interface simples com Raylib
- Integração opcional com Gemini (via `libcurl`) com fallback local

## Dependências
- C compiler com suporte a C11 (GCC/Clang/MSVC)
- Raylib instalada
- CMake 3.16+
- Opcional: libcurl para habilitar chamadas à API Gemini

## Passo a passo: rodando o jogo

1) Instale as dependências
- Windows (recomendado MinGW):
  - Instale o [CMake](`https://cmake.org/download/`).
  - Instale o MinGW (GCC) e adicione ao PATH.
  - Instale a Raylib (via pacotes ou compilando a partir da fonte) e garanta que as libs estejam acessíveis.
  - Opcional (para Gemini): instale `libcurl` e defina a variável `GEMINI_API_KEY`.
- Linux/macOS:
  - Use o gerenciador de pacotes para instalar `cmake`, `gcc/clang` e `raylib`.
  - Opcional: `libcurl` para habilitar Gemini.

2) Configure a build
- Crie uma pasta de build separada e gere o projeto com CMake:
  - Windows (PowerShell):
    ```powershell
    mkdir build; cd build
    cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release ..
    ```
  - Linux/macOS:
    ```bash
    mkdir -p build && cd build
    cmake -DCMAKE_BUILD_TYPE=Release ..
    ```

3) Compile
- Em ambas as plataformas:
  ```bash
  cmake --build . --config Release
  ```

4) (Opcional) Habilite a Gemini API
- Exige `libcurl` disponível e variável de ambiente com sua chave:
  - Windows (PowerShell):
    ```powershell
    $env:GEMINI_API_KEY = "SUA_CHAVE_AQUI"
    cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release -DUSE_CURL=ON ..
    cmake --build . --config Release
    ```
  - Linux/macOS:
    ```bash
    export GEMINI_API_KEY="SUA_CHAVE_AQUI"
    cmake -DCMAKE_BUILD_TYPE=Release -DUSE_CURL=ON ..
    cmake --build . --config Release
    ```

5) Execute o jogo
- Após a compilação, rode o executável dentro da pasta `build`:
  ```bash
  ./imobitech
  ```

6) Controles e objetivo
- Aperte `Espaço` para avançar o turno; `Enter` reinicia ao final.
- O jogo termina quando restar apenas 1 jogador com saldo positivo.

## Build

### Windows (PowerShell)
```powershell
# Em uma pasta de build
mkdir build
cd build

# Sem Gemini (mais simples)
cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --config Release

# Com Gemini (requer libcurl instalada e variável de ambiente GEMINI_API_KEY)
cmake -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release -DUSE_CURL=ON ..
cmake --build . --config Release
```

### Windows (w64devkit Raylib) sem CMake
- O PowerShell não expande `*.c`. Use os scripts fornecidos em `scripts/`:

PowerShell:
```powershell
pwsh -File scripts/compile_w64devkit.ps1
```

CMD (Prompt de Comando):
```bat
scripts\compile_w64devkit.bat
```

- Para habilitar Gemini com `libcurl` já instalada, defina antes:
```powershell
$env:USE_CURL = "1"
pwsh -File scripts/compile_w64devkit.ps1
```

### Linux/macOS
```bash
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --config Release
```

Se o CMake não encontrar a Raylib automaticamente, aponte caminhos manualmente ou instale via gerenciador de pacotes.

## Execução
```bash
./imobitech
```

- Use a tecla `Espaço` para avançar o turno.
- O jogo é automático nas decisões básicas: compra se tiver saldo, paga aluguel ao cair em propriedade alheia, aplica eventos e elimina jogadores com saldo negativo.

## Gemini API
- Variável de ambiente: `GEMINI_API_KEY`
- Modelo padrão: `gemini-1.5-flash`
- Caso `USE_CURL` esteja desabilitado ou a chave não esteja definida, o jogo usa um fallback local.

## Estrutura
```
src/
  ai.c/.h        # Integração Gemini (opcional com libcurl) e fallback
  board.c/.h     # Definição do tabuleiro e casas
  events.c/.h    # Lógica de eventos especiais
  game.c/.h      # Estado do jogo e regras de turno
  player.c/.h    # Funções utilitárias de jogador
  property.c/.h  # Compra, aluguel e propriedades
  ui.c/.h        # Renderização com Raylib
  main.c         # Ponto de entrada
```

## Grupos do projeto

### raylib
- Foco: interface e janela do jogo.
- Arquivos:
  - `src/main.c` (loop principal, janela)
  - `src/ui.h` e `src/ui.c` (renderização do tabuleiro, painel lateral)
- Dependências: Raylib.
- Instalação/Build: siga o "Passo a passo: rodando o jogo"; garanta que a Raylib esteja instalada.

### codigo:
- Foco: regras, estados e mecânicas (backend do jogo).
- Arquivos:
  - `src/game.h` e `src/game.c` (estado global, turnos, dados, vitória/eliminação)
  - `src/board.h` e `src/board.c` (layout do tabuleiro, casas e propriedades)
  - `src/player.h` e `src/player.c` (inicialização e dados de jogadores)
  - `src/property.h` e `src/property.c` (compra e aluguel)
  - `src/events.h` e `src/events.c` (Hackathon, Bug, Imposto)
- Observação: todo este grupo é compilado junto pelo CMake e é independente da Gemini API.

### ai (Gemini)
- Foco: geração de textos dinâmicos (opcional).
- Arquivos:
  - `src/ai.h` e `src/ai.c`
- Requisitos: `libcurl` + variável `GEMINI_API_KEY`.
- Como habilitar: configurar o CMake com `-DUSE_CURL=ON` (ver seção de Passo a passo).

## Onde e quando usar as estruturas de código e a ordenação

- Estruturas de dados (pastas `src/estruturas_dados/`):
  - Você vai consultar/alterar o tabuleiro em `board.*` para configurar as casas do jogo (bairros do Recife, tipos de casa) e acessar as propriedades (`Tile`, `Property`).
  - Você vai inicializar e acessar os jogadores em `player.*` (nome, saldo, cor, posição). Essas estruturas são usadas em praticamente todas as regras no grupo `codigo`.

- Ordenação (pasta `src/ordenacao/`):
  - O módulo `sort.*` fornece `sortPlayersByBalanceDesc`, que é usado na UI para mostrar o ranking de jogadores por saldo em tempo real.
  - Onde é usado: `src/raylib/ui.c` exibe a lista ordenada no painel lateral.

## Nova casa: Mistério (IA + economia dinâmica)

- Casa especial chamada "Mistério": quando um jogador cai nela, ocorre um evento global descrito pela IA (Gemini se habilitado, ou fallback local). O evento pode ser positivo (ex.: época de verão) ou negativo (ex.: pandemia, enchente no Recife).
- Efeito: os preços e aluguéis de todas as propriedades do tabuleiro são ajustados em ±10% a ±30%, dependendo do evento.
- Implementação:
  - Enum `TILE_MISTERIO` em `src/codigo/game.h`.
  - Lógica em `applyMisterio` (`src/codigo/events.c`) que:
    - Decide aleatoriamente se o evento é bom ou ruim e o percentual.
    - Ajusta `price` e `rent` de todas as `TILE_PROPERTY`.
    - Gera uma descrição com `aiGenerateText(...)`.
  - Integração no fluxo: `resolveLanding` em `src/codigo/game.c` chama `applyMisterio` quando a casa é do tipo Mistério.

## Bairros do Recife e valores

- As propriedades foram renomeadas para bairros do Recife e receberam preços/aluguéis proporcionais à classe do bairro. Exemplos:
  - Alta: Boa Viagem, Graças, Casa Forte
  - Média-alta: Espinheiro, Parnamirim, Bairro do Recife, Pina
  - Média: Madalena, Torre, Boa Vista
  - Média-baixa: Iputinga, Afogados
  - Baixa: Ibura, Cohab
- Esses valores são inicializados em `src/estruturas_dados/board.c`. A casa "Mistério" pode aumentar ou diminuir todos esses valores dinamicamente durante a partida.

## Interface (Raylib) e imagens simples

- A UI (`src/raylib/ui.c`) desenha:
  - Casas como círculos coloridos, com rótulos dos bairros nas propriedades;
  - Um ícone "?" nas casas de Mistério;
  - Painel lateral com turno, dado, saldos e ranking (ordenado por saldo);
  - Mensagens de eventos (incluindo texto da IA ao cair em Mistério).
- Imagens simples: por padrão são usados ícones desenhados por formas (círculos e o símbolo "?"). É possível trocar por texturas se você adicionar arquivos de imagem e carregar via `LoadTexture`.

## Licença
Uso educacional/demonstrativo.