$ErrorActionPreference = "Stop"

# Paths (adjust if your w64devkit is elsewhere)
$GCC = "C:/raylib/w64devkit/bin/gcc.exe"
$RAY_INC = "C:/raylib/w64devkit/x86_64-w64-mingw32/include"
$RAY_LIB = "C:/raylib/w64devkit/x86_64-w64-mingw32/lib"

# Ensure output directory exists
if (!(Test-Path output)) { New-Item -ItemType Directory -Path output | Out-Null }

$sources = @(
  "src/raylib/main.c",
  "src/raylib/ui.c",
  "src/codigo/game.c",
  "src/codigo/events.c",
  "src/codigo/property.c",
  "src/estruturas_dados/board.c",
  "src/estruturas_dados/player.c",
  "src/ia_usada/ai.c",
  "src/ordenacao/sort.c"
)

$includes = @(
  "-I", "src",
  "-I", "src/raylib",
  "-I", "src/codigo",
  "-I", "src/estruturas_dados",
  "-I", "src/ia_usada",
  "-I", "src/ordenacao",
  "-I", $RAY_INC
)

$libs = @(
  "-L", $RAY_LIB,
  "-lraylib", "-lopengl32", "-lgdi32", "-lwinmm", "-lws2_32", "-lpthread"
)

$defines = @()

if ($env:USE_CURL -eq "1") {
  $defines += "-DUSE_CURL"
  $libs += "-lcurl"
}

& $GCC @sources @includes @libs @defines -o "output/game.exe"
Write-Host "Build successful -> output/game.exe"


