@echo off
setlocal enabledelayedexpansion

set GCC=C:/raylib/w64devkit/bin/gcc.exe
set RAY_INC=C:/raylib/w64devkit/x86_64-w64-mingw32/include
set RAY_LIB=C:/raylib/w64devkit/x86_64-w64-mingw32/lib

if not exist output mkdir output

set SRC=^ 
 src/raylib/main.c ^
 src/raylib/ui.c ^
 src/codigo/game.c ^
 src/codigo/events.c ^
 src/codigo/property.c ^
 src/estruturas_dados/board.c ^
 src/estruturas_dados/player.c ^
 src/ia_usada/ai.c ^
 src/ordenacao/sort.c

set INC=-I src -I src/raylib -I src/codigo -I src/estruturas_dados -I src/ia_usada -I src/ordenacao -I %RAY_INC%
set LIB=-L %RAY_LIB% -lraylib -lopengl32 -lgdi32 -lwinmm -lws2_32 -lpthread
set DEF=

if "%USE_CURL%"=="1" (
  set DEF=-DUSE_CURL
  set LIB=%LIB% -lcurl
)

"%GCC%" %SRC% %INC% %LIB% %DEF% -o output/game.exe || goto :error

echo Build successful -> output\game.exe
exit /b 0

:error
echo Build failed
exit /b 1


